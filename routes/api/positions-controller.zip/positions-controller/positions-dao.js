//const  positionsModel = require('./positions-model.js');

import positionsModel from './positions-model.js';

export const findPositions = () => positionsModel.find();
export const createPosition = (position) => positionsModel.create(position);
export const deletePosition = (pid) => positionsModel.deleteOne({companyId: pid});
export const updatePosition = (pid, position) => positionsModel.updateOne({companyId: pid}, {$set: position})