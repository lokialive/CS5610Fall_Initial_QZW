import  mongoose from 'mongoose';
const schema = mongoose.Schema({
    companyId: {
        type: String,
    },
    positions: [
        {
            title: {
                type: String,
            },
            jobDescription: {
                type: String,
            },
            location: {
                type: String,
            },
        },
    ],
    date: {
        type: Date,
        default: Date.now,
    }

}, {collection: 'positions'});


export default schema;
