//const positionsDao = require('./positions-dao.js')
import * as positionsDao from './positions-dao.js'

const createPosition = async (req, res) => {
    const newPosition = req.body;
    const insertedPosition = await positionsDao.createPosition(newPosition);
    res.json(insertedPosition);
}



const findPositions  = async (req, res) => {
    const positions = await positionsDao.findPositions()
    res.json(positions);
}

const updatePosition = async (req, res) => {
    const positionIdToUpdate = req.params.pid;
    const updates = req.body;
    const status = await positionsDao.updatePosition(positionIdToUpdate, updates);
    res.json(status);

}



const deletePosition = async (req, res) => {
    const positionIdToDelete = req.params.pid;
    const status = await positionsDao.deletePosition(positionIdToDelete);

    res.json(status);
}


export default  (app) => {
    app.post('/api/positions', createPosition);
    app.get('/api/positions', findPositions);
    app.put('/api/positions/:pid', updatePosition);
    app.delete('/api/positions/:pid', deletePosition);
}
