import mongoose from 'mongoose';
import positionsSchema from './positions-schema.js'
const positionsModel = mongoose.model('PositionsModel', positionsSchema);
export default positionsModel;